define({
  "name": "Task API documentation",
  "version": "1.0.0",
  "description": "API task list manager",
  "template": {
    "forceLanguage": "en"
  },
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2021-02-17T16:50:05.396Z",
    "url": "http://apidocjs.com",
    "version": "0.23.0"
  }
});
