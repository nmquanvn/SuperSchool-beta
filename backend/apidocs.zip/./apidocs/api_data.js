define({ "api": [
  {
    "type": "post",
    "url": "/api/category/create",
    "title": "Create a category",
    "name": "Create_a_category",
    "group": "Category",
    "parameter": {
      "examples": [
        {
          "title": "Request-Example:",
          "content": "{\n    \"name\": \"C++\",\n    \"code\": \"C01\",\n    \"parentId\": null\n}",
          "type": "json"
        }
      ]
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n    \"data\": \"Success\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "routes/category.route.js",
    "groupTitle": "Category"
  },
  {
    "type": "delete",
    "url": "/api/category/delete/:id",
    "title": "Delete a category",
    "name": "Delete_a_category",
    "group": "Category",
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n    \"data\": \"Success\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "routes/category.route.js",
    "groupTitle": "Category"
  },
  {
    "type": "get",
    "url": "/api/category/getByParentId",
    "title": "Get Category by parentId",
    "name": "Get_Category_by_parentId",
    "group": "Category",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "parentId",
            "description": "<p>parentId = null nếu như là category cấp 1</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n    \"data\": [\n        {\n            \"categoryid\": \"1\",\n            \"name\": \"Lập trình\",\n            \"code\": \"CODE\",\n            \"parentid\": null\n        }\n    ]\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "routes/category.route.js",
    "groupTitle": "Category"
  },
  {
    "type": "get",
    "url": "/api/category/findById/:id",
    "title": "Get details of category",
    "name": "Get_details_of_category",
    "group": "Category",
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n    \"data\": {\n        \"categoryid\": \"6\",\n        \"name\": \"Lập trình Java\",\n        \"code\": \"C01.2\",\n        \"parentid\": \"4\",\n        \"english\": \"Java Basic\"\n    }\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "routes/category.route.js",
    "groupTitle": "Category"
  },
  {
    "type": "get",
    "url": "/api/category/register/top",
    "title": "Top course register",
    "name": "Top_course_register",
    "group": "Category",
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n    \"data\": [\n        {\n            \"categoryid\": \"2\",\n            \"name\": \"C++\",\n            \"code\": \"C++\",\n            \"parentid\": \"1\",\n            \"count\": \"2\"\n        }\n    ]\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "routes/category.route.js",
    "groupTitle": "Category"
  },
  {
    "type": "put",
    "url": "/api/category/update",
    "title": "Update a category",
    "name": "Update_a_category",
    "group": "Category",
    "parameter": {
      "examples": [
        {
          "title": "Request-Example:",
          "content": "{\n    \"categoryId\": 8, -- Bắt buộc\n    \"name\": \"Lập trình C++ 1234\",\n    \"code\": \"C01.12345\", \n    \"parentId\": null\n}",
          "type": "json"
        }
      ]
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n    \"data\": \"Success\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "routes/category.route.js",
    "groupTitle": "Category"
  },
  {
    "type": "get",
    "url": "/api/course/findById/:id",
    "title": "Find course by id",
    "name": "Find_course_by_id",
    "group": "Courses",
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n    \"data\": {\n        \"courseid\": \"3\",\n        \"title\": \"Lập trình Java căn bản\",\n        \"imagePath\": null,\n        \"description\": \"\",\n        \"detailDescription\": \"\",\n        \"views\": \"0\",\n        \"createddate\": \"2021-01-09T09:22:06.842Z\",\n        \"updateddate\": null,\n        \"price\": \"1200000.00\",\n        \"categoryid\": \"6\",\n        \"teacherid\": \"4\",\n        \"status\": \"INCOMPLETE\"\n    }\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "routes/course.route.js",
    "groupTitle": "Courses"
  },
  {
    "type": "get",
    "url": "/api/course/findByCategoryId",
    "title": "Get course by categoryId",
    "name": "Get_course_by_categoryId",
    "group": "Courses",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "categoryId",
            "description": "<p>Id của category khóa học.(Bắt buộc)</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Request-Example:",
          "content": "{\n    \"page\": 1, \n    \"pageSize\": 10\n}",
          "type": "json"
        }
      ]
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n    \"data\": [\n        {\n            \"courseid\": \"4\",\n            \"title\": \"Lập trình C++ \",\n            \"imagePath\": null,\n            \"description\": null,\n            \"detailDescription\": null,\n            \"views\": \"0\",\n            \"createddate\": \"2021-01-02T17:00:00.000Z\",\n            \"price\": \"1500000.00\",\n            \"categoryid\": \"2\",\n            \"teacherid\": \"1\"\n        }\n    ]\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "routes/course.route.js",
    "groupTitle": "Courses"
  },
  {
    "type": "get",
    "url": "/api/course/search",
    "title": "Search courses",
    "name": "Search_courses",
    "group": "Courses",
    "parameter": {
      "examples": [
        {
          "title": "Request-Example:",
          "content": "{\n    \"pageSize\": 10,\n    \"page\": 1,\n    \"searchString\": \"\",\n    \"categoryId\": 2\n}",
          "type": "json"
        }
      ]
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n    \"data\": [\n        {\n            \"courseid\": \"4\",\n            \"title\": \"Lập trình C++ \",\n            \"imagePath\": null,\n            \"description\": null,\n            \"detailDescription\": null,\n            \"views\": \"0\",\n            \"createddate\": \"2021-01-02T17:00:00.000Z\",\n            \"price\": \"1500000.00\",\n            \"categoryid\": \"2\",\n            \"teacherid\": \"1\"\n        }\n    ]\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "routes/course.route.js",
    "groupTitle": "Courses"
  },
  {
    "type": "get",
    "url": "/api/course/register/top",
    "title": "Top registration",
    "name": "Top_registration",
    "group": "Courses",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "quantity",
            "description": "<p>Số lượng khóa học có lượt đăng ký cao nhất (bắt buộc)</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n    \"data\": [\n        {\n            \"courseid\": \"5\",\n            \"title\": \"Hướng đối tượng với C++\",\n            \"imagePath\": null,\n            \"description\": null,\n            \"detailDescription\": null,\n            \"views\": \"4\",\n            \"createddate\": \"2021-01-02T17:00:00.000Z\",\n            \"price\": \"500000.00\",\n            \"categoryid\": \"2\",\n            \"teacherid\": \"1\",\n            \"countQuantityRegister\": \"2\"\n        }\n    ]\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "routes/course.route.js",
    "groupTitle": "Courses"
  },
  {
    "type": "get",
    "url": "/api/course/views/top",
    "title": "Top views",
    "name": "Top_views",
    "group": "Courses",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "quantity",
            "description": "<p>Số lượng khóa học có lượt view cao nhất (bắt buộc)</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n    \"data\": [\n        {\n            \"courseid\": \"5\",\n            \"title\": \"Hướng đối tượng với C++\",\n            \"imagePath\": null,\n            \"description\": null,\n            \"detailDescription\": null,\n            \"views\": \"4\",\n            \"createddate\": \"2021-01-02T17:00:00.000Z\",\n            \"price\": \"500000.00\",\n            \"categoryid\": \"2\",\n            \"teacherid\": \"1\"\n        }\n    ]\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "routes/course.route.js",
    "groupTitle": "Courses"
  },
  {
    "type": "post",
    "url": "/api/users/refresh-token",
    "title": "Refresh Token",
    "name": "Refresh_Token",
    "group": "Users",
    "parameter": {
      "examples": [
        {
          "title": "Request-Example:",
          "content": "{\n    \"refresh_token\": \"QhnibXASPJRiDt46hDBWQGljURlZnfgkTOV8U6FRCkVqo0P3Rwx4QBjl9DBFyqLYt41jEiKQWjhUCTFn0ESFu2HLGgiu8pAXolHvhCGihEdCBKne3rh4erT5vv3Kc3yjM4EvjQ4Czine7D15oKT5Qh4d5uKgTrHao3BlzceL7HuTL9WKcWMn9YR9OVDoyjGsRwvNXKqE85xaT4XMWtoIdyH2vGCWTiVVF5T4cV2N2Ju4l7bVNrgD5CyXBd4gUFl\"\n}",
          "type": "json"
        }
      ]
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n    \"access_token\": \"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIxNCIsInVzZXJuYW1lIjoidGllbnFkIiwiZnVsbG5hbWUiOiJRdWFjaCBEaW5oIFRpZW4iLCJwaG9uZU51bWJlciI6bnVsbCwiZW1haWwiOm51bGwsImdyb3VwQ29kZSI6IlNUVURFTlQiLCJpYXQiOjE2MDk1MTYxNzV9.zLGJpdGPrGs6BbfL5r6G1OW3xVhrG-cdzZEeczx2hAI\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "routes/user.route.js",
    "groupTitle": "Users"
  },
  {
    "type": "post",
    "url": "/api/auth/register",
    "title": "Đăng ký",
    "name": "Đăng_ký",
    "group": "Users",
    "parameter": {
      "examples": [
        {
          "title": "Request-Example:",
          "content": "{\n    \"username\": \"tienqd\",            --bắt buộc\n    \"password\": \"123456\",            --bắt buộc\n    \"usergroupid\": 2,                --bắt buộc\n    \"fullname\": \"Quach Dinh Tien\"    --bắt buộc\n}",
          "type": "json"
        }
      ]
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n    \"access_token\": \"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIxNCIsInVzZXJuYW1lIjoidGllbnFkIiwiZnVsbG5hbWUiOiJRdWFjaCBEaW5oIFRpZW4iLCJwaG9uZU51bWJlciI6bnVsbCwiZW1haWwiOm51bGwsInJlZnJlc2hfdG9rZW4iOiJRaG5pYlhBU1BKUmlEdDQ2aERCV1FHbGpVUmxabmZna1RPVjhVNkZSQ2tWcW8wUDNSd3g0UUJqbDlEQkZ5cUxZdDQxakVpS1FXamhVQ1RGbjBFU0Z1MkhMR2dpdThwQVhvbEh2aENHaWhFZENCS25lM3JoNGVyVDV2djNLYzN5ak00RXZqUTRDemluZTdEMTVvS1Q1UWg0ZDV1S2dUckhhbzNCbHpjZUw3SHVUTDlXS2NXTW45WVI5T1ZEb3lqR3NSd3ZOWEtxRTg1eGFUNFhNV3RvSWR5SDJ2R0NXVGlWVkY1VDRjVjJOMkp1NGw3YlZOcmdENUN5WEJkNGdVRmwiLCJncm91cENvZGUiOiJTVFVERU5UIiwiaWF0IjoxNjA5NTEzMTA1fQ.URyTjNUu0fg54zXeXH9OENXVISmdTpmOfaihnBfN2x4\",\n    \"refresh_token\": \"QhnibXASPJRiDt46hDBWQGljURlZnfgkTOV8U6FRCkVqo0P3Rwx4QBjl9DBFyqLYt41jEiKQWjhUCTFn0ESFu2HLGgiu8pAXolHvhCGihEdCBKne3rh4erT5vv3Kc3yjM4EvjQ4Czine7D15oKT5Qh4d5uKgTrHao3BlzceL7HuTL9WKcWMn9YR9OVDoyjGsRwvNXKqE85xaT4XMWtoIdyH2vGCWTiVVF5T4cV2N2Ju4l7bVNrgD5CyXBd4gUFl\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "routes/auth.route.js",
    "groupTitle": "Users"
  },
  {
    "type": "post",
    "url": "/api/auth/login",
    "title": "Đăng nhập",
    "name": "Đăng_nhập",
    "group": "Users",
    "parameter": {
      "examples": [
        {
          "title": "Request-Example:",
          "content": "{\n    \"username\": \"tienqd\",    -- bắt buộc\n    \"password\": \"123456\"     -- bắt buộc\n}",
          "type": "json"
        }
      ]
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n    \"access_token\": \"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIxNCIsInVzZXJuYW1lIjoidGllbnFkIiwiZnVsbG5hbWUiOiJRdWFjaCBEaW5oIFRpZW4iLCJwaG9uZU51bWJlciI6bnVsbCwiZW1haWwiOm51bGwsInJlZnJlc2hfdG9rZW4iOiJRaG5pYlhBU1BKUmlEdDQ2aERCV1FHbGpVUmxabmZna1RPVjhVNkZSQ2tWcW8wUDNSd3g0UUJqbDlEQkZ5cUxZdDQxakVpS1FXamhVQ1RGbjBFU0Z1MkhMR2dpdThwQVhvbEh2aENHaWhFZENCS25lM3JoNGVyVDV2djNLYzN5ak00RXZqUTRDemluZTdEMTVvS1Q1UWg0ZDV1S2dUckhhbzNCbHpjZUw3SHVUTDlXS2NXTW45WVI5T1ZEb3lqR3NSd3ZOWEtxRTg1eGFUNFhNV3RvSWR5SDJ2R0NXVGlWVkY1VDRjVjJOMkp1NGw3YlZOcmdENUN5WEJkNGdVRmwiLCJncm91cENvZGUiOiJTVFVERU5UIiwiaWF0IjoxNjA5NTEzMTA1fQ.URyTjNUu0fg54zXeXH9OENXVISmdTpmOfaihnBfN2x4\",\n    \"refresh_token\": \"QhnibXASPJRiDt46hDBWQGljURlZnfgkTOV8U6FRCkVqo0P3Rwx4QBjl9DBFyqLYt41jEiKQWjhUCTFn0ESFu2HLGgiu8pAXolHvhCGihEdCBKne3rh4erT5vv3Kc3yjM4EvjQ4Czine7D15oKT5Qh4d5uKgTrHao3BlzceL7HuTL9WKcWMn9YR9OVDoyjGsRwvNXKqE85xaT4XMWtoIdyH2vGCWTiVVF5T4cV2N2Ju4l7bVNrgD5CyXBd4gUFl\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "routes/auth.route.js",
    "groupTitle": "Users"
  }
] });
